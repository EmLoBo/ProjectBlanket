create definer = root@localhost trigger insert_order
    before insert
    on koszyk
    for each row
BEGIN
    UPDATE magazyn SET stan_magazynowy = stan_magazynowy-1
    WHERE magazyn.ksiazki_id = NEW.ksiazki_id;
    END;

